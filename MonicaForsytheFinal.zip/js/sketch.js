var scene;
var weather;
var night;
var day;

var rain; 
var fog; 
var cloud;
var snow;

function preload() {
  var url =
   'http://api.openweathermap.org/data/2.5/weather?q=Baltimore&APPID=569330567deac54bf69bba6cc00f4a60';
  weather = loadJSON(url);

  scene = loadImage("scene.jpg");
  day = loadImage('daytime.jpg');
  night = loadImage('nighttime.jpg');

  snow = loadAnimation('assets/snow0000.png snow0295.png');
  rain = loadAnimation('assets/rain0000.png, rain0295.png');      //all PNG's NOT WORKING
  fog = loadImage('assets/fog0000.png', 'assets/fog0295.png');
  cloud = loadAnimation('assets/day/cloudy/cloud.png');
  }

function setup() {
  createCanvas(700,1000);
  console.log(weather);
  noLoop();
  }

function draw() {
  var weathertemp = weather.main.temp;
  var weathertemp= Math.floor(Math.trunc((weather.main.temp)*9/5-459.67));
  var cityname = weather.name;

  background(scene);
  
  console.log(weathertemp);

  push();
    fill('yellow');
    strokeWeight(3);
    stroke('black');
    textSize(60);
    text(cityname, 220, 78);
  pop();

  push();
  console.log("Thermometer");
    if (weathertemp > 0) {
        strokeWeight(.1);
        fill('red');
        rect(637, 373, 7, -weathertemp);    //THERMOMETER
      } else if (weathertemp < 0){
        rect(637,373, 7, 5);
        setInterval(thermometer, 10000);  //MOVED FOR CLARITY. WAS AT THE END OF DRAW FUNCTION
      }
      textSize(23)
      text(weathertemp +'°', 655, 365);
  pop();

  //push();
    //noStroke();
    //fill('lightGray');
    //rect(187,236,326,357);  //WINDOW PLACEMENT
  //pop();

  setInterval(clockReset, 100); 
  
  weatherWindow();

}

function clockReset() {   
  //console.log("is this functioning working?");
  clock();
   }

function clock() {               //RUNNING OFF OF COMPUTER TIME, NOT API
  //console.log("is this functioning working?");

  var currentTime = new Date();
  var hr = currentTime.getHours();
  var min = currentTime.getMinutes();
  var meridiem = " AM";


  if (hr > 12) {
    hr = hr - 12;
    meridiem = ' PM';
  } else if (hr > 12 && hr < 22) {
    hr = '0' + hr;
  }  else if (hr > 0 && hr < 12) {
      hr = hr;
  } else if (hr === 0) {
      hr = 12; 
  } if (hr > 12 && hr < 22 || hr > 0 && hr < 10) {
  hr = '0' + hr;    
  }
  
  if (min < 10) {
    min = '0' + min;
  }
  
  textSize(25);
  fill('lightGray'); 
  rect(166.5,643,110,57);
  fill ('black');
  text (hr + ':' + min + meridiem, 168,683);
          
        }
    
function weatherWindow() {
  var sunset = weather.sys.sunset;
  var sunrise = weather.sys.sunrise;
  var time = weather.dt;
  console.log(time);
  console.log(sunrise);
  console.log(sunset);

  if (time > sunrise && time < sunset) {
    image(day,188,237);
        } 
  if (time > sunrise && time > sunset || time < sunrise && time < sunset) {
    image(night,188,237); 
        }

  console.log("is this functioning working?");
  condition();

  }
function condition() {     //'ANIMATION' NOT WORKING  IMAGES JUST OVERLAPPING
  var weatherCondition =  weather.weather[0].main;
  console.log(weatherCondition);

  textSize(30);
  text('(' + weatherCondition + ')', 315, 225);

  if (weatherCondition = 'Clouds') {
    //image(cloud, 188, 237);
        //console.log("it clouds");
  }
  if (weatherCondition = 'Fog', 'Haze', 'Mist') {
    //image(fog, 188, 237);
    //fog.play();  
    console.log("it's fog");
  }
  if (weatherCondition = 'Rain') {
    //rain.addAnimation(188, 237);                   //'ANIMATION()' NOT WORKING
    console.log("it's rain");
  } 
  if (weatherCondition = 'Snow') {
    //Animation(snow, 188, 237);
        console.log("it's snow");
  }
  console.log("is this last function working?");

  }

 